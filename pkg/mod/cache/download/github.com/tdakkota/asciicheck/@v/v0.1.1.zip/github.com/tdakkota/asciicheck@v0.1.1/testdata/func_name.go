package testdata

func TеstFunc() { // want `identifier "TеstFunc" contain non-ASCII character: U\+0435 'е'`

}
