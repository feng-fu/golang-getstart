import HomepageComponent from '../components/Homepage';

export default HomepageComponent;
