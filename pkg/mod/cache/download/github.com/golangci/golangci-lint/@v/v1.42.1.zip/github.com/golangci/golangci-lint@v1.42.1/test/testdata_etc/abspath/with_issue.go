package abspath

import "fmt"

func f() {
	if true {
		return
	} else {
		fmt.Printf("")
	}
}
