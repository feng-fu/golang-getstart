package main

import "errors"

var (
	ErrorFailed = errors.New("something went wrong")
)
